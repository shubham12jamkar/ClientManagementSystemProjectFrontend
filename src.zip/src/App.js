
// import './App.css';
import Login from './components/Login';
import Dashboard from './components/Dashboard';
import { BrowserRouter as Router,  Routes, Route } from "react-router-dom";
// import NavBar from './layout/NavBar';
function App() {
  return (
    //  <div className="page">
    // {/* //   <Login/> */}
    //    {/* <Dashboard/> */}
    //    {/* <NavBar/> */}

    //  </div>

    <Router>
        <div>
          <Routes>
            <Route  exact path="/" element={<Login/>}></Route>
            <Route  path="Dashboard" element={<Dashboard/>}></Route>
          </Routes>
        </div>
       
      </Router>
  );
}

export default App;
