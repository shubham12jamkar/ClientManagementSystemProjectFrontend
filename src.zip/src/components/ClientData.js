// import React from "react";

const ClientData = [
    {
        id: 1,
        clientName: "Merk",
        startDate: '2019-04-11',
        endDate: '2023-04-11',
        contactPersonClient: 9876543210,
        contactPersonYash: 8787654398,
        clientStatus: "true"
    },
    {
        id: 2,
        clientName: "TCI",
        startDate: '2019-04-11',
        endDate: '2023-04-11',
        contactPersonClient: 9988665667,
        contactPersonYash: 7654987654,
        clientStatus: "true"
    },
    {
        id: 3,
        clientName: "SLB",
        startDate: '2019-04-11',
        endDate: '2023-04-11',
        contactPersonClient: 8877665499,
        contactPersonYash: 9876789876,
        clientStatus: "true"
    }
]
export default ClientData