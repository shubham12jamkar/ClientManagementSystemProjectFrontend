import React, { useState } from "react";
import ClientData from "./ClientData";
import Swal from 'sweetalert2'

import AddClient from "./AddClient";
import EditClient from "./EditClient";
import Header from "./Header";
import List from "./List";

function Dashboard (){
    const [clients, setClients] = useState(ClientData);
    const [selectedClient, setSelectedClient]=useState(null);
    const [isAdding, setIsAdding] = useState(false);
    const [isEditing, setIsEditing] = useState(false);

    const handleEdit = (id) => {
        // console.log(id)
         const [client] = clients.filter(client => client.id === id);
        
         setSelectedClient(client);
         setIsEditing(true);
    }


    const handleDelete = (id) => {
        // console.log(id)
        Swal.fire({
            icon: 'warning',
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            showCancelButton: true,
            confirmButtonText: 'Yes, delete it!',
            cancelButtonText: 'No, cancel!',
        }).then(result => {
            if (result.value) {
                const [client] = clients.filter(client => client.id === id);

                Swal.fire({
                    icon: 'success',
                    title: 'Deleted!',
                    text: `${client.clientName} data has been deleted.`,
                    showConfirmButton: false,
                    timer: 1500,
                });

                setClients(clients.filter(client => client.id !== id));
            }
        });
    }

    return(
    
             <div className='container'>
            {/* List */}
            {!isAdding && !isEditing && (
                <>
                    <Header
                        setIsAdding={setIsAdding}
                    />
                    <List
                         clients={clients}
                         handleEdit={handleEdit}
                         handleDelete={handleDelete}
                    />
                </>
            )}
            {/* Add */}
            {isAdding && (
                <AddClient
                    clients={clients}
                    setClients={setClients}
                    setIsAdding={setIsAdding}
                />
            )}
            {/* Edit */}
            {isEditing && (
                <EditClient
                    clients={clients}
                    selectedClient={selectedClient}
                    setClients={setClients}
                    setIsEditing={setIsEditing}
                />
            )}
        </div>
    )
}
export default Dashboard