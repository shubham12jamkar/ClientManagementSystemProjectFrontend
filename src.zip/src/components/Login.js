// import React, { useState } from "react";
import { useNavigate } from "react-router";
import "./Login.css"

const Login = () => {


    const navigate = useNavigate();
    function handClick() {
        navigate("/Dashboard")
    }

    return (

        <div className="page">
            <div className="cover" >
                <form>
                    <h1>Login</h1>
                    <input type="text" placeholder="username" />
                    <input type="password" placeholder="password" />

                    <div className="login-btn" onClick={handClick}>Login</div>
                </form>
            </div>
        </div>

    )
}
export default Login