import React, { useEffect, useRef, useState } from 'react'
import Swal from 'sweetalert2';

function AddClient({ clients, setClients, setIsAdding }) {
    const [clientName, setClientName] = useState('');
    const [startDate, setStartDate] = useState('');
    const [endDate, setEndDate] = useState('');
    const [contactPersonClient, setContactPersonClient] = useState('');
    const [contactPersonYash, setContactPersonYash] = useState('');
    const [clientStatus, setClientStatus] = useState('');

    const textInput = useRef(null);

    useEffect(() => {
        textInput.current.focus();
    }, [])

    const handleAdd = e => {
        e.preventDefault();
        if (!clientName || !startDate || !endDate || !contactPersonClient || !contactPersonYash || !clientStatus) {
            return Swal.fire({
                icon: 'error',
                title: 'Error!',
                text: 'All fields are required.',
                showConfirmButton: true
            });
        }
        const id = clients.length + 1;
        const newClient = {
            id,
            clientName,
            startDate,
            endDate,
            contactPersonClient,
            contactPersonYash,
            clientStatus
        }
        clients.push(newClient);
        setClients(clients);
        setIsAdding(false);

        Swal.fire({
            icon: 'success',
            title: 'Added!',
            text: `${clientName} data has been Added.`,
            showConfirmButton: false,
            timer: 5000
        });
    }
    return (
        <div className="small-container">
            <form onSubmit={handleAdd}>
                <h1>Add Client</h1>
                <label htmlFor="clientName">Client Name</label>
                <input
                    id="clientName"
                    type="text"
                    ref={textInput}
                    name="clientName"
                    value={clientName}
                    onChange={c => setClientName(c.target.value)}
                />
                <label htmlFor="startDate">Start Date</label>
                <input
                    id="startDate"
                    type="date"
                    name="startDate"
                    value={startDate}
                    onChange={c => setStartDate(c.target.value)}
                />
                <label htmlFor="endDate">End Date</label>
                <input
                    id="endDate"
                    type="date"
                    name="endDate"
                    value={endDate}
                    onChange={c => setEndDate(c.target.value)}
                />
                <label htmlFor="contactPersonClient">Contact Client</label>
                <input
                    id="contactPersonClient"
                    type="number"
                    name="contactPersonClient"
                    value={contactPersonClient}
                    onChange={c => setContactPersonClient(c.target.value)}
                />
                <label htmlFor="contactPersonYash">Contact Yash</label>
                <input
                    id="contactPersonYash"
                    type="number"
                    name="contactPersonYash"
                    value={contactPersonYash}
                    onChange={c => setContactPersonYash(c.target.value)}
                />
                <label htmlFor="clientStatus">Status</label>
                <input
                    id="clientStatus"
                    type="text"
                    name="clientStatus"
                    value={clientStatus}
                    onChange={c => setClientStatus(c.target.value)}
                />
                <div style={{ marginTop: '30px' }}>
                    <input type="submit" value="Add" />
                    <input
                        style={{ marginLeft: '12px' }}
                        className="muted-button"
                        type="button"
                        value="Cancel"
                        onClick={() => setIsAdding(false)}
                    />
                </div>
            </form>
        </div>
    )
}

export default AddClient
