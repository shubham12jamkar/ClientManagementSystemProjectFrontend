import React from 'react'

function NavBar() {
  return (
    <div >
      <h1>Client Management System</h1>
    </div>
  )
}

export default NavBar
